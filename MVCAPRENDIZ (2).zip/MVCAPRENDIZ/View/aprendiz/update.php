<?php

require_once("../../Model/Aprendiz.php");
require_once("../../Controller/AprendizController.php");

$nombre = $_POST['txtNombre'];
$correo = $_POST['txtCorreo'];
$id= $_POST['txtID'];

$aprendiz = new Aprendiz($id, $nombre, $correo);

$controlador = new AprendizController();

$controlador->update($aprendiz);

?>