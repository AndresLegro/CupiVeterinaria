<?php
include("../templates/header.php");

require_once("../../Controller/AprendizController.php");

$controlador = new AprendizController();
$registros= $controlador->index();

?>

<div class="card">
    <div class="card-header">
        Lista de Aprendices
    </div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre:</th>
                        <th scope="col">Correo:</th>
                        <th scope="col">Acciones:</th>                   
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if($registros):
                            foreach ($registros as $fila):
                    ?>
                        <tr class="">
                            <td scope="row"><?php echo $fila['ID'];?></td>
                            <td scope="row"><?php echo $fila['nombre'];?></td>
                            <td scope="row"><?php echo $fila['correo'];?></td>
                            <td>
                                <a href="show.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-success">Ver</a>
                                <a href="edit.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-warning">Editar</a>
                                <a href="delete.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-danger">Eliminar</a>
                            </td>
                        </tr>
                    
                    <?php
                        endforeach;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
        
    </div>
    
</div>

<?php
    include("../templates/footer.php");
?>
