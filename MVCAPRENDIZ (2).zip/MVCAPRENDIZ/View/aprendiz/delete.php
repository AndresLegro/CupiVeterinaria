<?php 
    include("../templates/header.php");

    $id = $_GET['id'];
    
    require_once("../../Controller/AprendizController.php");
    
    $controlador = new AprendizController();
    $registro = $controlador->show($id);
?>

<div class="card">
    <div class="card-header">
        Eliminar Aprendiz
    </div>
    <div class="card-body">
        <form action="drop.php" method="post">
            
    <div class="table-responsive">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">Dato</th>
                        <th scope="col">Valor</th>
                     
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td scope="row">ID:</td>
                        <td><?php echo $registro['ID']; ?></td>
                        <input type="hidden" name="txtID" value="<?php echo $registro['ID']; ?>">
                   
                    </tr>
                    <tr class="">
                        <td scope="row">Nombre:</td>
                        <td><?php echo $registro['nombre']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Correo:</td>
                        <td><?php echo $registro['correo']; ?></td>
                    </tr>
                </tbody>
            </table>
                <button type="submit" class="btn btn-danger">Eliminar</button>
                <a href="index.php" class="btn btn-info">Regresar</a>
        </form>
        </div>
</div>

<?php

include("../templates/footer.php");

?>