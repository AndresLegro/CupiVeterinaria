<?php

require_once("../../Model/Aprendiz.php");
require_once("../../Controller/AprendizController.php");

$nombre = $_POST['txtNombre'];
$correo = $_POST['txtCorreo'];

$aprendiz = new Aprendiz(0, $nombre, $correo);

$controlador = new AprendizController();

$controlador->insert($aprendiz);

?>