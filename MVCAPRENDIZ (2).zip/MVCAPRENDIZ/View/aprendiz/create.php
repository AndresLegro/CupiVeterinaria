<?php
    include("../templates/header.php");
?>
<div class="card">
    <div class="card-header">
        Agregar Aprendiz
    </div>
    <div class="card-body">
        <form action="store.php" method="POST">

            <div class="mb-3">
                <label for="" class="form-label">Nombre: </label>
                <input type="text" class="form-control" name="txtNombre" id="txtNombre" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Correo electronico: </label>
                <input type="email" class="form-control" name="txtCorreo" id="txtCorreo" aria-describedby="helpId" placeholder="">
            </div>

            <button type="submit" class="btn btn-success">Guardar</button>
            <a href="index.php" class="btn btn-danger">Cancelar</a>

        </form>
    </div>
    
</div>



<?php
    include("../templates/footer.php");
?>