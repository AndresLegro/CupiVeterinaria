<?php

include("../templates/header.php");

$id = $_GET['id'];

require_once("../../Model/Aprendiz.php");
require_once("../../Controller/AprendizController.php");

$controlador = new AprendizController();
$registro = $controlador->show($id);

?>

<div class="card">
    <div class="card-header">
        Registro del Aprendiz
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">Dato</th>
                        <th scope="col">Valor</th>
                     
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td scope="row">ID:</td>
                        <td><?php echo $registro['ID']; ?></td>
                   
                    </tr>
                    <tr class="">
                        <td scope="row">Nombre:</td>
                        <td><?php echo $registro['nombre']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Correo:</td>
                        <td><?php echo $registro['correo']; ?></td>
                    </tr>
                </tbody>
            </table>
                <a href="index.php" class="btn btn-success">Ir a la pagina principal</a>

        </div>
        
    </div>
    
</div>

<?php

include("../templates/footer.php");

?>

