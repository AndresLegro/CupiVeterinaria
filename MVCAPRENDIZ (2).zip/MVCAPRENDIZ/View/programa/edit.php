<?php

include("../templates/header.php");

$id = $_GET['id'];

require_once("../../Controller/ProgramaController.php");

$controlador = new ProgramaController();
$registro = $controlador->show($id);

?>

<div class="card">
    <div class="card-header">
        Editar Programa
    </div>
    <div class="card-body">
        <form action="update.php" method="POST">

            <div class="mb-3">
                <label for="" class="form-label">ID: </label>
                <input type="text" value = "<?php echo $registro['ID']; ?>" readonly class="form-control" name="txtID"
                    id="txtID" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Descripcion: </label>
                <input type="text" value="<?php echo $registro['descripcion']; ?>" class="form-control" name="txtDescripcion"
                    id="txtDescripcion" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Siglas: </label>
                <input type="text" value="<?php echo $registro['sigla']; ?>" class="form-control" name="txtSigla"
                    id="txtSigla" aria-describedby="helpId" placeholder="">
            </div>

            <button type="submit" class="btn btn-success">Guardar</button>
            <a href="index.php" class="btn btn-danger">Cancelar</a>

        </form>
    </div>

</div>

<?php

include("../templates/footer.php");

?>