<?php 
    include("../templates/header.php");

    $id = $_GET['id'];
    
    require_once("../../Controller/ProgramaController.php");
    
    $controlador = new ProgramaController();
    $registro = $controlador->show($id);
?>

<div class="card">
    <div class="card-header">
        Eliminar programa
    </div>
    <div class="card-body">
        <form action="drop.php" method="post">
            
    <div class="table-responsive">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">Dato</th>
                        <th scope="col">Valor</th>
                     
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td scope="row">ID:</td>
                        <td><?php echo $registro['ID']; ?></td>
                        <input type="hidden" name="txtID" value="<?php echo $registro['ID']; ?>">
                   
                    </tr>
                    <tr class="">
                        <td scope="row">Descripcion:</td>
                        <td><?php echo $registro['descripcion']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Sigla:</td>
                        <td><?php echo $registro['sigla']; ?></td>
                    </tr>
                </tbody>
            </table>
                <button type="submit" class="btn btn-danger">Eliminar</button>
                <a href="index.php" class="btn btn-info">Regresar</a>
        </form>
        </div>
</div>

<?php

include("../templates/footer.php");

?>