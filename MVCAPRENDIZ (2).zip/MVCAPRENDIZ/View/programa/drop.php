<?php

require_once("../../Model/Programa.php");
require_once("../../Controller/ProgramaController.php");

$descripcion = "";
$sigla = "";
$id = $_POST['txtID'];

$programa = new Programa($id, $descripcion, $sigla);

$controlador = new ProgramaController();

$controlador->delete($programa);

?>