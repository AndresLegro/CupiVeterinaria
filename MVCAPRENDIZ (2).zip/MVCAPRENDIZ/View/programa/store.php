<?php

require_once("../../Model/Programa.php");
require_once("../../Controller/ProgramaController.php");

$descripcion = $_POST['txtDescripcion'];
$sigla = $_POST['txtSigla'];

$programa = new Programa(0, $descripcion, $sigla);

$controlador = new ProgramaController();

$controlador->insert($programa);

?>