<?php
include("../templates/header.php");

require_once("../../Controller/ProgramaController.php");

$controlador = new ProgramaController();
$registros= $controlador->index();

?>

<div class="card">
    <div class="card-header">
        Lista de programas
    </div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Descripcion:</th>
                        <th scope="col">Sigla:</th>
                        <th scope="col">Opciones:</th>                   
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if($registros):
                            foreach ($registros as $fila):
                    ?>
                        <tr class="">
                            <td scope="row"><?php echo $fila['ID'];?></td>
                            <td scope="row"><?php echo $fila['descripcion'];?></td>
                            <td scope="row"><?php echo $fila['sigla'];?></td>
                            <td>
                                <a href="show.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-success">Ver</a>
                                <a href="edit.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-warning">Editar</a>
                                <a href="delete.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-danger">Eliminar</a>
                            </td>
                        </tr>
                    
                    <?php
                        endforeach;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
        
    </div>
    
</div>

<?php
    include("../templates/footer.php");
?>
