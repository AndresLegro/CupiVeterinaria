<?php

include("../templates/header.php");

$id = $_GET['id'];

require_once("../../Model/Aprendiz.php");
require_once("../../Controller/ProgramaController.php");

$controlador = new ProgramaController();
$registro = $controlador->show($id);

?>

<div class="card">
    <div class="card-header">
        Registro del Programa
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">Dato</th>
                        <th scope="col">Valor</th>
                     
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td scope="row">ID:</td>
                        <td><?php echo $registro['ID']; ?></td>
                   
                    </tr>
                    <tr class="">
                        <td scope="row">Descripcion:</td>
                        <td><?php echo $registro['descripcion']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Sigla:</td>
                        <td><?php echo $registro['sigla']; ?></td>
                    </tr>
                </tbody>
            </table>
                <a href="index.php" class="btn btn-success">Ir a la pagina principal</a>

        </div>
        
    </div>
    
</div>

<?php

include("../templates/footer.php");

?>

