<?php

require_once("../../Model/Programa.php");
require_once("../../Controller/ProgramaController.php");

$descripcion = $_POST['txtDescripcion'];
$sigla = $_POST['txtSigla'];
$id= $_POST['txtID'];

$programa = new Programa($id, $descripcion, $sigla);

$controlador = new ProgramaController();

$controlador->update($programa);

?>