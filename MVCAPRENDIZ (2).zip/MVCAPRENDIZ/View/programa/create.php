<?php
    include("../templates/header.php");

    require_once("../../Controller/ProgramaController.php");

    $controlador = new ProgramaController();
    $registros= $controlador->index();

?>
<div class="card">
    <div class="card-header">
        Agregar Programa
    </div>
    <div class="card-body">
        <form action="store.php" method="POST">

            <div class="mb-3">
                <label for="txtDescripcion" class="form-label">Descripcion: </label>
                <input type="text" class="form-control" name="txtDescripcion" id="txtDescripcion" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="txtSigla" class="form-label">Sigla: </label>
                <input type="text" class="form-control" name="txtSigla" id="txtSigla" aria-describedby="helpId" placeholder="">
            </div>

            <button type="submit" class="btn btn-success">Guardar</button>
            <a href="index.php" class="btn btn-danger">Cancelar</a>

            <select name="" id="">

                <option value="<?php echo id ?>"><?php echo $descripcion ?></option>

            </select>

        </form>
    </div>
    
</div>



<?php
    include("../templates/footer.php");
?>