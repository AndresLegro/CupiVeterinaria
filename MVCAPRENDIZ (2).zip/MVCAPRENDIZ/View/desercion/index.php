<?php
include("../templates/header.php");

require_once("../../Controller/DesercionController.php");

$controlador = new DesercionController();
$registros= $controlador->index();

?>

<div class="card">
    <div class="card-header">
        Lista de deserciones
    </div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre:</th>
                        <th scope="col">Apellido:</th>
                        <th scope="col">Instructor:</th>
                        <th scope="col">Centro:</th>
                        <th scope="col">Opciones:</th>                   
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if($registros):
                            foreach ($registros as $fila):
                    ?>
                        <tr class="">
                            <td scope="row"><?php echo $fila['ID'];?></td>
                            <td scope="row"><?php echo $fila['nombre'];?></td>
                            <td scope="row"><?php echo $fila['apellidos'];?></td>
                            <td scope="row"><?php echo $fila['instructor'];?></td>
                            <td scope="row"><?php echo $fila['centro'];?></td>
                            <td>
                                <a href="show.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-success">Ver</a>
                                <a href="edit.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-warning">Editar</a>
                                <a href="delete.php?id=<?php echo $fila ['ID']; ?>" class="btn btn-danger">Eliminar</a>
                            </td>
                        </tr>
                    
                    <?php
                        endforeach;
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
        
    </div>
    
</div>

<?php
    include("../templates/footer.php");
?>
