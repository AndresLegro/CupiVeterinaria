<?php

include("../templates/header.php");

$id = $_GET['id'];

require_once("../../Controller/DesercionController.php");

$controlador = new DesercionController();
$registro = $controlador->show($id);

?>

<div class="card">
    <div class="card-header">
        Editar Desercion
    </div>
    <div class="card-body">
        <form action="update.php" method="POST">

            <div class="mb-3">
                <label for="" class="form-label">ID: </label>
                <input type="text" value = "<?php echo $registro['ID']; ?>" readonly class="form-control" name="txtID"
                    id="txtID" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Nombre: </label>
                <input type="text" value = "<?php echo $registro['nombre']; ?>" class="form-control" name="txtNombre" id="txtNombre" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Apellidos: </label>
                <input type="text" value = "<?php echo $registro['apellidos']; ?>"  class="form-control" name="txtApellidos" id="txtApellidos" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Tipo de Documento: </label>
                <input type="text" value = "<?php echo $registro['tipoDocumento']; ?>" class="form-control" name="txtTipoDocumento" id="txtTipoDocumento" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Centro: </label>
                <input type="text" value = "<?php echo $registro['centro']; ?>" class="form-control" name="txtCentro" id="txtCentro" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Codigo de Centro: </label>
                <input type="number" value = "<?php echo $registro['codigoCentro']; ?>" class="form-control" name="txtCodigoCentro" id="txtCodigoCentro" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Programa: </label>
                <input type="text" value = "<?php echo $registro['programa']; ?>" class="form-control" name="txtPrograma" id="txtPrograma" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Numero de Ficha: </label>
                <input type="number" value = "<?php echo $registro['numeroFicha']; ?>" class="form-control" name="txtNumeroFicha" id="txtNumeroFicha"  aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Instructor: </label>
                <input type="text" value = "<?php echo $registro['instructor']; ?>" class="form-control" name="txtInstructor" id="txtInstructor"  aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Fecha de inicio del programa: </label>
                <input type="date" value = "<?php echo $registro['fechaInicioPrograma']; ?>" class="form-control" name="txtFechaInicioPrograma" id="txtFechaInicioPrograma"  aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Jornada: </label>
                <input type="text" value = "<?php echo $registro['jornada']; ?>" class="form-control" name="txtJornada" id="txtJornada"  aria-describedby="helpId" placeholder="">
            </div>
            
            <div class="mb-3">
                <label for="" class="form-label">Fecha de retiro del programa: </label>
                <input type="date" value = "<?php echo $registro['fechaRetiroPrograma']; ?>" class="form-control" name="txtFechaRetiroPrograma" id="txtFechaRetiroPrograma" aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Causa del retiro: </label>
                <input type="text" value = "<?php echo $registro['causaRetiro']; ?>" class="form-control" name="txtCausaRetiro" id="txtCausaRetiro"  aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Descripcion de la causa: </label>
                <input type="text" value = "<?php echo $registro['descripcionCausa']; ?>" class="form-control" name="txtDescripcionCausa" id="txtDescripcionCausa"  aria-describedby="helpId" placeholder="">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Observacion: </label>
                <input type="text" value = "<?php echo $registro['observacion']; ?>" class="form-control" name="txtObservacion" id="txtObservacion"  aria-describedby="helpId" placeholder="">
            </div>

            <button type="submit" class="btn btn-success">Guardar</button>
            <a href="index.php" class="btn btn-danger">Cancelar</a>

        </form>
    </div>

</div>

<?php

include("../templates/footer.php");

?>