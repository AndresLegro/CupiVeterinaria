<?php

require_once("../../Model/Desercion.php");
require_once("../../Controller/DesercionController.php");

$nombre = $_POST['txtNombre'];
$apellidos = $_POST['txtApellidos'];
$tipoDocumento = $_POST['txtTipoDocumento'];
$centro = $_POST['txtCentro'];
$codigoCentro = $_POST['txtCodigoCentro'];
$programa = $_POST['txtPrograma'];
$numeroFicha = $_POST['txtNumeroFicha'];
$instructor = $_POST['txtInstructor'];
$fechaInicioPrograma = $_POST['txtFechaInicioPrograma'];
$jornada = $_POST['txtJornada'];
$fechaRetiroPrograma = $_POST['txtFechaRetiroPrograma'];
$causaRetiro = $_POST['txtCausaRetiro'];
$descripcionCausa = $_POST['txtDescripcionCausa'];
$observacion = $_POST['txtObservacion'];
$id= $_POST['txtID'];

$desercion = new Desercion($id, $nombre, $apellidos, $tipoDocumento, $centro, $codigoCentro, $programa, $numeroFicha, $instructor, $fechaInicioPrograma, $jornada, $fechaRetiroPrograma, $causaRetiro, $descripcionCausa, $observacion);

$controlador = new DesercionController();

$controlador->update($desercion);

?>