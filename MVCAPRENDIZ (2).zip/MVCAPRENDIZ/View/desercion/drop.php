<?php

require_once("../../Model/Desercion.php");
require_once("../../Controller/DesercionController.php");

$nombre = "";
$apellidos = "";
$tipoDocumento = "";
$centro = "";
$codigoCentro = "";
$programa = "";
$numeroFicha = "";
$instructor = "";
$fechaInicioPrograma = "";
$jornada = "";
$fechaRetiroPrograma = "";
$causaRetiro = "";
$descripcionCausa = "";
$observacion = "";
$id = $_POST['txtID'];

$desercion = new Desercion($id, $nombre, $apellidos, $tipoDocumento, $centro, $codigoCentro, $programa, $numeroFicha, $instructor, $fechaInicioPrograma, $jornada, $fechaRetiroPrograma, $causaRetiro, $descripcionCausa, $observacion);

$controlador = new DesercionController();

$controlador->delete($desercion);
?>