<?php 
    include("../templates/header.php");

    $id = $_GET['id'];
    
    require_once("../../Controller/DesercionController.php");
    
    $controlador = new DesercionController();
    $registro = $controlador->show($id);
?>

<div class="card">
    <div class="card-header">
        Eliminar Desercion
    </div>
    <div class="card-body">
        <form action="drop.php" method="post">
            
    <div class="table-responsive">
            <table class="table ">
                <thead>
                    <tr>
                        <th scope="col">Dato</th>
                        <th scope="col">Valor</th>
                     
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td scope="row">ID:</td>
                        <td><?php echo $registro['ID']; ?></td>
                        <input type="hidden" name="txtID" value="<?php echo $registro['ID']; ?>">
                   
                    </tr>
                    <tr class="">
                        <td scope="row">Nombre:</td>
                        <td><?php echo $registro['nombre']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Apellidos:</td>
                        <td><?php echo $registro['apellidos']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Tipo documento:</td>
                        <td><?php echo $registro['tipoDocumento']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Centro:</td>
                        <td><?php echo $registro['centro']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">codigo centro:</td>
                        <td><?php echo $registro['codigoCentro']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">programa:</td>
                        <td><?php echo $registro['programa']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">numero ficha:</td>
                        <td><?php echo $registro['numeroFicha']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Instructor:</td>
                        <td><?php echo $registro['instructor']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Fecha inicio programa:</td>
                        <td><?php echo $registro['fechaInicioPrograma']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Jornada:</td>
                        <td><?php echo $registro['jornada']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">fecha retiro programa:</td>
                        <td><?php echo $registro['fechaRetiroPrograma']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Causa retiro:</td>
                        <td><?php echo $registro['causaRetiro']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Descripcion causa:</td>
                        <td><?php echo $registro['descripcionCausa']; ?></td>
                    </tr>

                    <tr class="">
                        <td scope="row">Observacion:</td>
                        <td><?php echo $registro['observacion']; ?></td>
                    </tr>

                </tbody>
            </table>
                <button type="submit" class="btn btn-danger">Eliminar</button>
                <a href="index.php" class="btn btn-info">Regresar</a>
        </form>
        </div>
</div>

<?php

include("../templates/footer.php");

?>