<?php
require_once(__DIR__ . "/../Model/Aprendiz.php");
require_once(__DIR__ . "/../Model/AprendizModel.php");

    class AprendizController

    {
        private $model;

        public function __construct()
        {
            $this->model = new AprendizModel();
        }

        public function insert (Aprendiz $aprendiz)
        {
            $id = $this->model->insert($aprendiz);

            return ($id != false) ? header ("Location:show.php?id=" . $id) : header ("Location:create.php");
        }

        public function show($id)
        {
            $registro = $this->model->show($id);
            return ($registro != false) ? $registro : header ("Location:index.php");
        }

        public function index()
        {
            $registros = $this->model->index();
            return $registros;
        }

        public function update (Aprendiz $aprendiz)
        {
            $id = $this->model->update($aprendiz);

            return ($id != false) ? header ("Location:show.php?id=" . $id) : header ("Location:index.php");        
        }

        public function delete (Aprendiz $aprendiz)
        {
            $resultado = $this->model->delete($aprendiz);

            return $resultado ? header ("Location:index.php") : header ("Location:show.php?id=" . $aprendiz->getId());        
        }



    }

?>