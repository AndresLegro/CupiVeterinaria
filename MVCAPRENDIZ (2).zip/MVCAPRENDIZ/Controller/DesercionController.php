<?php
require_once(__DIR__ . "/../Model/Desercion.php");
require_once(__DIR__ . "/../Model/DesercionModel.php");

    class DesercionController

    {
        private $model;

        public function __construct()
        {
            
            $this->model = new DesercionModel();
        }

        public function insert (Desercion $desercion)
        {
            $id = $this->model->insert($desercion);

            return ($id != false) ? header ("Location:show.php?id=" . $id) : header ("Location:create.php");
        }

        public function show($id)
        {
            $registro = $this->model->show($id);
            return ($registro != false) ? $registro : header ("Location:index.php");
        }

        public function index()
        {
            $registros = $this->model->index();
            return $registros;
        }

        public function update (Desercion $desercion)
        {
            $id = $this->model->update($desercion);

            return ($id != false) ? header ("Location:show.php?id=" . $id) : header ("Location:index.php");        
        }

        public function delete (Desercion $desercion)
        {
            $resultado = $this->model->delete($desercion);

            return $resultado ? header ("Location:index.php") : header ("Location:show.php?id=" . $desercion->getId());        
        }



    }

?>