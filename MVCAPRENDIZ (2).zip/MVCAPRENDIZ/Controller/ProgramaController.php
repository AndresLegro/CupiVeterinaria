<?php
require_once(__DIR__ . "/../Model/Programa.php");
require_once(__DIR__ . "/../Model/ProgramaModel.php");

    class ProgramaController

    {
        private $model;

        public function __construct()
        {
            
            $this->model = new ProgramaModel();
        }

        public function insert (Programa $programa)
        {
            $id = $this->model->insert($programa);

            return ($id != false) ? header ("Location:show.php?id=" . $id) : header ("Location:create.php");
        }

        public function show($id)
        {
            $registro = $this->model->show($id);
            return ($registro != false) ? $registro : header ("Location:index.php");
        }

        public function index()
        {
            $registros = $this->model->index();
            return $registros;
        }

        public function update (Programa $programa)
        {
            $id = $this->model->update($programa);

            return ($id != false) ? header ("Location:show.php?id=" . $id) : header ("Location:index.php");        
        }

        public function delete (Programa $programa)
        {
            $resultado = $this->model->delete($programa);

            return $resultado ? header ("Location:index.php") : header ("Location:show.php?id=" . $programa->getId());        
        }



    }

?>