<?php

class Desercion
{
    private $id;
    private $nombre;
    private $apellidos;
    private $tipoDocumento;
    private $centro;
    private $codigoCentro;
    private $programa;
    private $numeroFicha;
    private $instructor;
    private $fechaInicioPrograma;
    private $jornada;
    private $fechaRetiroPrograma;
    private $causaRetiro;
    private $descripcionCausa;
    private $observacion;



    public function __construct($id, $nombre, $apellidos, $tipoDocumento, $centro, $codigoCentro, $programa, $numeroFicha, $instructor, $fechaInicioPrograma, $jornada, $fechaRetiroPrograma, $causaRetiro, $descripcionCausa, $observacion)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->apellidos = $apellidos;
        $this->tipoDocumento = $tipoDocumento;
        $this->centro = $centro;
        $this->codigoCentro = $codigoCentro;
        $this->programa = $programa;
        $this->numeroFicha = $numeroFicha;
        $this->instructor = $instructor;
        $this->fechaInicioPrograma = $fechaInicioPrograma;
        $this->jornada = $jornada;
        $this->fechaRetiroPrograma = $fechaRetiroPrograma;
        $this->causaRetiro = $causaRetiro;
        $this->descripcionCausa = $descripcionCausa;
        $this->observacion = $observacion;
        
    }

    public function getId()
    {
        return $this->id;
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function getApellidos()
    {
        return $this->apellidos;
    }

    public function getTipoDocumento()
    {
        return $this->tipoDocumento;
    }

    public function getCentro()
    {
        return $this->centro;
    }

    public function getCodigoCentro()
    {
        return $this->codigoCentro;
    }

    public function getPrograma()
    {
        return $this->programa;
    }

    public function getNumeroFicha()
    {
        return $this->numeroFicha;
    }

    public function getInstructor()
    {
        return $this->instructor;
    }

    public function getFechaInicioPrograma()
    {
        return $this->fechaInicioPrograma;
    }

    public function getJornada()
    {
        return $this->jornada;
    }

    public function getFechaRetiroPrograma()
    {
        return $this->fechaRetiroPrograma;
    }

    public function getCausaRetiro()
    {
        return $this->causaRetiro;
    }

    public function getDescripcionCausa()
    {
        return $this->descripcionCausa;
    }

    public function getObservacion()
    {
        return $this->observacion;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    public function setApellidos($apellidos)
    {
        $this->apellidos = $apellidos;
    }

    public function setTipoDocumento ($tipoDocumento)
    
    {
        $this->tipoDocumento = $tipoDocumento;
    }

    public function setCentro($centro)
    {
        $this->centro = $centro;
    }

    public function setCodigoCentro($codigoCentro)
    {
        $this->codigoCentro = $codigoCentro;
    }

    public function setPrograma ($programa)
    
    {
        $this->programa = $programa;
    }

    public function setNumeroFicha($numeroFicha)
    {
        $this->numeroFicha = $numeroFicha;
    }

    public function setInstructor($instructor)
    {
        $this->instructor = $instructor;
    }

    public function setFechaInicioPrograma ($fechaInicioPrograma)
    
    {
        $this->fechaInicioPrograma = $fechaInicioPrograma;
    }

    public function setCausaRetiro($causaRetiro)
    {
        $this->causaRetiro = $causaRetiro;
    }

    public function setDescripcionCausa($descripcionCausa)
    {
        $this->descripcionCausa = $descripcionCausa;
    }

    public function setObservacion ($observacion)
    
    {
        $this->observacion = $observacion;
    }


}


?>