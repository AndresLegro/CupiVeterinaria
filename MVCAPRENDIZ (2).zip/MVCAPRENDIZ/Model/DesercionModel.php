<?php
require_once("Desercion.php");

class DesercionModel 
{
    private $pdo;

    public function __construct()
    {
        require_once(__DIR__ . "/../Config/DB.php");
        $conexion = new DB("localhost" , "sena", "root" ,"");
        $this->pdo = $conexion->connect();
    }

    public function insert(Desercion $desercion)
    {
        $statement = $this->pdo->prepare("INSERT INTO desercion(nombre, apellidos, tipoDocumento, centro, codigoCentro, programa, numeroFicha, instructor, fechaInicioPrograma, jornada, fechaRetiroPrograma, causaRetiro, descripcionCausa, observacion)  
        VALUES(:nombre, :apellidos, :tipoDocumento, :centro, :codigoCentro, :programa, :numeroFicha, :instructor, :fechaInicioPrograma, :jornada, :fechaRetiroPrograma, :causaRetiro, :descripcionCausa, :observacion)");
       
       $statement->bindParam(":nombre", $nombre);
        $statement->bindParam(":apellidos", $apellidos);
        $statement->bindParam(":tipoDocumento", $tipoDocumento);
        $statement->bindParam(":centro", $centro);
        $statement->bindParam(":codigoCentro", $codigoCentro);
        $statement->bindParam(":programa", $programa);
        $statement->bindParam(":numeroFicha", $numeroFicha);
        $statement->bindParam(":instructor", $instructor);
        $statement->bindParam(":fechaInicioPrograma", $fechaInicioPrograma);
        $statement->bindParam(":jornada", $jornada);
        $statement->bindParam(":fechaRetiroPrograma", $fechaRetiroPrograma);
        $statement->bindParam(":causaRetiro", $causaRetiro);
        $statement->bindParam(":descripcionCausa", $descripcionCausa);
        $statement->bindParam(":observacion", $observacion);

        $nombre = $desercion->getNombre();
        $apellidos = $desercion->getApellidos();
        $tipoDocumento = $desercion->getTipoDocumento();
        $centro = $desercion->getCentro();
        $codigoCentro = $desercion->getCodigoCentro();
        $programa = $desercion->getPrograma();
        $numeroFicha = $desercion->getNumeroFicha();
        $instructor = $desercion->getInstructor();
        $fechaInicioPrograma = $desercion->getFechaInicioPrograma();
        $jornada = $desercion->getJornada();
        $fechaRetiroPrograma = $desercion->getFechaRetiroPrograma();
        $causaRetiro = $desercion->getCausaRetiro();
        $descripcionCausa = $desercion->getDescripcionCausa();
        $observacion = $desercion->getObservacion();

        return ($statement->execute()) ? $this->pdo->lastInsertID() : false;
    }

    public function show($id)
    {
        $statement = $this->pdo->prepare("SELECT * FROM desercion WHERE id = :id LIMIT 1");
        $statement->bindParam(":id", $id);

        return ($statement->execute()) ? $statement->fetch() : false;
    }

        /**
         * Muestra todos los registros de aprendices existentes
         * @return aprendices
         */
        public function index()
        {
            $statement = $this->pdo->prepare("SELECT * FROM desercion");
            return ($statement->execute()) ? $statement->fetchAll() : false;
        }

        /**
         * Actualiza el registro de un aprendiz dado por parametro
         * @param aprendiz 
         * @return id del aprendiz actualizado o false si falla.
         */
        public function update(Desercion $desercion)
        {
            $statement = $this->pdo->prepare("UPDATE desercion SET nombre = :nombre, apellidos = :apellidos, tipoDocumento = :tipoDocumento, centro = :centro, codigoCentro = :codigoCentro, programa = :programa, numeroFicha = :numeroFicha, instructor = :instructor, fechaInicioPrograma = :fechaInicioPrograma, jornada = :jornada, fechaRetiroPrograma = :fechaRetiroPrograma, causaRetiro = :causaRetiro, descripcionCausa = :descripcionCausa, observacion = :observacion WHERE id = :id");
        
            $statement->bindParam(":nombre", $nombre);
            $statement->bindParam(":apellidos", $apellidos);
            $statement->bindParam(":tipoDocumento", $tipoDocumento);
            $statement->bindParam(":centro", $centro);
            $statement->bindParam(":codigoCentro", $codigoCentro);
            $statement->bindParam(":programa", $programa);
            $statement->bindParam(":numeroFicha", $numeroFicha);
            $statement->bindParam(":instructor", $instructor);
            $statement->bindParam(":fechaInicioPrograma", $fechaInicioPrograma);
            $statement->bindParam(":jornada", $jornada);
            $statement->bindParam(":fechaRetiroPrograma", $fechaRetiroPrograma);
            $statement->bindParam(":causaRetiro", $causaRetiro);
            $statement->bindParam(":descripcionCausa", $descripcionCausa);
            $statement->bindParam(":observacion", $observacion);
            $statement->bindParam(":id", $id);
        
            $nombre = $desercion->getNombre();
            $apellidos = $desercion->getApellidos();
            $tipoDocumento = $desercion->getTipoDocumento();
            $centro = $desercion->getCentro();
            $codigoCentro = $desercion->getCodigoCentro();
            $programa = $desercion->getPrograma();
            $numeroFicha = $desercion->getNumeroFicha();
            $instructor = $desercion->getInstructor();
            $fechaInicioPrograma = $desercion->getFechaInicioPrograma();
            $jornada = $desercion->getJornada();
            $fechaRetiroPrograma = $desercion->getFechaRetiroPrograma();
            $causaRetiro = $desercion->getCausaRetiro();
            $descripcionCausa = $desercion->getDescripcionCausa();
            $observacion = $desercion->getObservacion();
            $id = $desercion->getId();
        
            return ($statement->execute()) ? $desercion->getId() : false;
        }
        

        /**
         * Borra un aprendiz dado por parametro de la base de datos
         * @return true si se pudo borrar o false en caso contrario.
         */ 
        public function delete( Desercion $desercion)
        {
            $statement = $this->pdo->prepare("DELETE FROM desercion WHERE id = :id");
            $statement->bindParam(":id" , $desercion->getId());


            return ($statement->execute()) ? true : false;
        }



    }

?>