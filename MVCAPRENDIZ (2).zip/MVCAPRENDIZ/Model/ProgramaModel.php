<?php
//require_once("Programa.php");

    class ProgramaModel 
    {
        private $pdo;
        
        public function __construct()
        
        {
            require_once(__DIR__ . "/../Config/DB.php");
            $conexion = new DB("localhost" , "sena", "root" ,"");
            $this->pdo = $conexion->connect();

        }

        public function insert( Programa $programa)
        {
            $statement = $this->pdo->prepare("INSERT INTO programa(descripcion, sigla, estado) VALUES(:descripcion, :sigla, :estado)");
            $statement->bindParam(":descripcion" , $programa->getDescripcion());
            $statement->bindParam(":sigla" , $programa->getSigla());
            $statement->bindParam(":estado" , $programa->getEstado());

            return ($statement->execute()) ? $this->pdo->lastInsertID() : false;
        }

        public function show($id)
        {
            $statement = $this->pdo->prepare("SELECT * FROM programa WHERE id = :id AND estado = 'ACT'");
            $statement->bindParam(":id" , $id);

            return ($statement->execute()) ? $statement->fetch() : false;

        }

        /**
         * Muestra todos los registros de programas existentes
         * @return programas
         */
        public function index()
        {
            $statement = $this->pdo->prepare("SELECT * FROM programa WHERE estado = 'ACT'");
            return ($statement->execute()) ? $statement->fetchAll() : null;
        }

        /**
         * Actualiza el registro de un aprendiz dado por parametro
         * @param programa 
         * @return id del programa actualizado o false si falla.
         */
        public function update (Programa $programa)
        {
            $statement = $this->pdo->prepare("UPDATE programa SET descripcion = :descripcion, sigla = :sigla WHERE id = :id");
            $statement->bindParam(":descripcion" , $programa->getDescripcion());
            $statement->bindParam(":sigla" , $programa->getSigla());
            $statement->bindParam(":id" , $programa->getId());


            return ($statement->execute()) ? $programa->getId() : false;
        }

        /**
         * Borra un aprendiz dado por parametro de la base de datos
         * @return true si se pudo borrar o false en caso contrario.
         */ 
        public function delete( Programa $programa)
        {
            $statement = $this->pdo->prepare("UPDATE programa SET estado = 'INA' WHERE id = :id");
            $statement->bindParam(":id" , $programa->getId());


            return ($statement->execute()) ? true : false;
        }



    }

?>