<?php

class Programa
{
    private $id;
    private $descripcion;
    private $sigla;
    private $estado;

    public function __construct($id, $descripcion, $sigla)
    {
        $this->id = $id;
        $this->descripcion = $descripcion;
        $this->sigla = $sigla;
        $this->estado = 'ACT';
        
    }

    public function getId()
    {
        return $this->id;
    }

    public function getDescripcion()
    {
        return $this->descripcion;
    }

    public function getSigla()
    {
        return $this->sigla;
    }

    public function getEstado()
    {
        return $this->estado;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }

    public function setSigla($sigla)
    {
        $this->sigla = $sigla;
    }

    public function setEstado ($estado)
    
    {
        $this->estado = $estado;
    }


}


?>