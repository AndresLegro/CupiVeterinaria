<?php
require_once("Aprendiz.php");

    class AprendizModel 
    {
        private $pdo;
        
        public function __construct()
        
        {
            require_once(__DIR__ . "/../Config/DB.php");
            $conexion = new DB("localhost" , "sena", "root" ,"");
            $this->pdo = $conexion->connect();

        }

        public function insert( Aprendiz $aprendiz)
        {
            $statement = $this->pdo->prepare("INSERT INTO aprendiz(nombre, correo) VALUES(:nombre, :correo)");
            $statement->bindParam(":nombre" , $aprendiz->getNombre());
            $statement->bindParam(":correo" , $aprendiz->getCorreo());

            return ($statement->execute()) ? $this->pdo->lastInsertID() : false;
        }

        public function show($id)
        {
            $statement = $this->pdo->prepare("SELECT * FROM aprendiz WHERE id = :id LIMIT 1");
            $statement->bindParam(":id" , $id);

            return ($statement->execute()) ? $statement->fetch() : false;

        }

        /**
         * Muestra todos los registros de aprendices existentes
         * @return aprendices
         */
        public function index()
        {
            $statement = $this->pdo->prepare("SELECT * FROM aprendiz");
            return ($statement->execute()) ? $statement->fetchAll() : false;
        }

        /**
         * Actualiza el registro de un aprendiz dado por parametro
         * @param aprendiz 
         * @return id del aprendiz actualizado o false si falla.
         */
        public function update (Aprendiz $aprendiz)
        {
            $statement = $this->pdo->prepare("UPDATE aprendiz SET nombre = :nombre, correo = :correo WHERE id = :id");
            $statement->bindParam(":nombre" , $aprendiz->getNombre());
            $statement->bindParam(":correo" , $aprendiz->getCorreo());
            $statement->bindParam(":id" , $aprendiz->getId());


            return ($statement->execute()) ? $aprendiz->getId() : false;
        }

        /**
         * Borra un aprendiz dado por parametro de la base de datos
         * @return true si se pudo borrar o false en caso contrario.
         */ 
        public function delete( Aprendiz $aprendiz)
        {
            $statement = $this->pdo->prepare("DELETE FROM aprendiz WHERE id = :id");
            $statement->bindParam(":id" , $aprendiz->getId());


            return ($statement->execute()) ? true : false;
        }



    }

?>