<?php

    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With ");

    //Conexion a la base de datos

    $servidor = "localhost";
    $usuario = "root";
    $contrasenia= "";
    $nombreBaseDatos = "sena";

    $conexionBD= new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

    //Consultar datos y recepcionar una clave pk para la consulta

    if(isset ($_GET["consultar"]))
    {
        $sqlAprendices = mysqli_query($conexionBD, "SELECT * FROM aprendiz WHERE id = " . $_GET["consultar"]);

        if (mysqli_num_rows($sqlAprendices) > 0)
        {
            $aprendices = mysqli_fetch_all($sqlAprendices , MYSQLI_ASSOC);

            echo json_encode($aprendices);
        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();
    }


    // Borrar un registro, y recepcionar una clave pk para el borrado

    if(isset ($_GET["borrar"]))
    {
        $sqlAprendices = mysqli_query($conexionBD, "DELETE  FROM aprendiz WHERE id = " . $_GET["borrar"]);

        if ($sqlAprendices)
        {
            echo json_encode(["success"=>1]);

        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();
    }

    // Insertar un registro nuevo, y recepcionar por metodo POST los datos del aprendiz

    if (isset($_GET["insertar"]) && $_SERVER["REQUEST_METHOD"] === "POST") 
    {
        $data = json_decode(file_get_contents("php://input"));
    
        if (!empty($data->nombre) && !empty($data->correo)) 
        {
            $nombre = $data->nombre;
            $correo = $data->correo;
    
            $sqlAprendices = mysqli_query($conexionBD, "INSERT INTO aprendiz (nombre, correo) VALUES ('$nombre', '$correo')");
    
            if ($sqlAprendices) 
            {
                echo json_encode(["success" => 1]);
            } 

            else 
            {
                echo json_encode(["success" => 0]);
            }
        } 
        
        else 
        {
            echo json_encode(["success" => 0]);
        }
    
        exit();
    }
    
     //Actualiza un registro y recepciona por metodo POST los datos del aprendiz

     if(isset($_GET["actualizar"]))
     {
         $id = $_GET['actualizar'];
     
         $data = json_decode(file_get_contents("php://input"));
     
         $nombre = $data->nombre;
     
         $correo = $data->correo;
     
         $sqlAprendices = mysqli_query($conexionBD, "UPDATE aprendiz SET nombre = '$nombre', correo = '$correo' WHERE id = $id");
     
         if ($sqlAprendices)
         {
             echo json_encode(["success" => 1]);
         }
         else
         {
             echo json_encode(["success" => 0]);
         }
     
         exit();
     }
     

     //Consultar todos los registros


    $sqlAprendices = mysqli_query($conexionBD, "SELECT * FROM aprendiz");

    if (mysqli_num_rows($sqlAprendices) > 0) 
    {
        $aprendices = mysqli_fetch_all($sqlAprendices, MYSQLI_ASSOC);

        echo json_encode($aprendices);
    } 
    
    else 
    {
        echo json_encode(["success" => 0]);
    }

    exit();


?>