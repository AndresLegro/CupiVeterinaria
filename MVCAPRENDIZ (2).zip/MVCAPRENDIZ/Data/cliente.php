<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With ");

    //Conexion a la base de datos

    $servidor = "localhost";
    $usuario = "root";
    $contrasenia= "";
    $nombreBaseDatos = "cupiveterinaria";

    $conexionBD= new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

    if (isset($_GET['consultar'])) {
        $idCliente = $_GET['consultar'];

        $sqlCliente = mysqli_query($conexionBD, "SELECT * FROM cliente WHERE cedula = $idCliente");

        if ($sqlCliente && mysqli_num_rows($sqlCliente) > 0) 
        {
            $cliente = mysqli_fetch_all($sqlCliente, MYSQLI_ASSOC);
            echo json_encode($cliente);
        } 
        else 
        {
            echo json_encode(["success" => 0]);
        }

        exit();
    }


    if(isset($_GET['borrar']))
    {
        $sqlCliente = mysqli_query($conexionBD, "DELETE FROM cliente WHERE cedula = " . $_GET["borrar"]);
        if($sqlCliente)
        {
            echo json_encode(["success" => 1]);
        }
        else
        {
            echo json_encode(["success" => 0]);
        }
        exit();
    }


    if(isset($_GET['insertar']))
    {
        $data = json_decode(file_get_contents("php://input"));

        $cedula = $data->cedula;
        $nombreCompleto = $data->nombreCompleto;
        $direccion = $data->direccion;
        $correo = $data->correo;

        if (!empty($cedula) && !empty($nombreCompleto) && !empty($direccion) && !empty($correo)) {
            
            $sqlCliente = mysqli_query($conexionBD, "INSERT INTO cliente (cedula, nombreCompleto, direccion, correo ) 
                                            VALUES ('$cedula' ,'$nombreCompleto', '$direccion', '$correo')");
            if($sqlCliente)
            {
                echo json_encode(["success" => 1]);
            }
            else
            {
                echo json_encode(["success" => 0]);
            }
        }
        exit();
    }

    if (isset($_GET['actualizar'])) 
    {
        $data = json_decode(file_get_contents("php://input"));
 
        $nombreCompleto = $data->nombreCompleto;
        $direccion = $data->direccion;
        $correo = $data->correo;


        if (!empty($nombreCompleto)) {
            $sqlCliente = mysqli_query($conexionBD, "UPDATE cliente SET nombreCompleto = '$nombreCompleto', 
                            direccion = '$direccion', correo = '$correo' WHERE cedula = " . $_GET['actualizar']);

            if($sqlCliente)
            {
                echo json_encode(["success" => 1]);
            }
            else
            {
                echo json_encode(["success" => 0]);
            }
        }

        exit();
    }


    $sqlCliente = mysqli_query($conexionBD, "SELECT * FROM cliente");

    if (mysqli_num_rows($sqlCliente) > 0) 
    {
        $cliente = mysqli_fetch_all($sqlCliente, MYSQLI_ASSOC);
        echo json_encode($cliente);
    }

    else 
    {
        echo json_encode(["success" => 0]);
    }

    exit();

?>