<?php

    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With ");

    //Conexion a la base de datos

    $servidor = "localhost";
    $usuario = "root";
    $contrasenia= "";
    $nombreBaseDatos = "sena";

    $conexionBD= new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

    //Consultar datos y recepcionar una clave pk para la consulta

    if(isset ($_GET["consultar"]))
    {
        $sqlProgramas = mysqli_query($conexionBD, "SELECT * FROM programa WHERE id = " . $_GET["consultar"]);

        if (mysqli_num_rows($sqlProgramas) > 0)
        {
            $programas = mysqli_fetch_all($sqlProgramas , MYSQLI_ASSOC);

            echo json_encode($programas);
        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();
    }


    // Borrar un registro, y recepcionar una clave pk para el borrado

    if(isset ($_GET["borrar"]))
    {
        $sqlProgramas = mysqli_query($conexionBD, "UPDATE programa SET estado = 'INA' WHERE id = " . $_GET["borrar"]);

        if ($sqlProgramas)
        {
            echo json_encode(["success"=>1]);

        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();
    }

    // Insertar un registro nuevo, y recepcionar por metodo POST los datos del aprendiz

    if (isset($_GET["insertar"]) && $_SERVER["REQUEST_METHOD"] === "POST") 
    {
        $data = json_decode(file_get_contents("php://input"));
    
        if (!empty($data->descripcion) && !empty($data->sigla)) 
        {
            $descripcion = $data->descripcion;
            $sigla = $data->sigla;
    
            $sqlProgramas = mysqli_query($conexionBD, "INSERT INTO programa (descripcion, sigla) VALUES ('$descripcion', '$sigla')");
    
            if ($sqlProgramas) 
            {
                echo json_encode(["success" => 1]);
            } 

            else 
            {
                echo json_encode(["success" => 0]);
            }
        } 
        
        else 
        {
            echo json_encode(["success" => 0]);
        }
    
        exit();
    }

     //Actualiza un registro y recepciona por metodo POST los datos del aprendiz

     if(isset ($_GET["actualizar"]))
     {
        $id= $_GET['actualizar'];

        $data= json_decode(file_get_contents("php://input"));

        $descripcion= $data->descripcion;

        $sigla= $data->sigla;
        
        $sqlProgramas = mysqli_query($conexionBD, "UPDATE  programa  SET descripcion = '$descripcion', sigla = '$sigla'  WHERE id = $id  ");

        if ($sqlProgramas)
        {
            echo json_encode(["success"=>1]);

        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();

     }

     //Consultar todos los registros


    $sqlProgramas = mysqli_query($conexionBD, "SELECT * FROM programa");

    if (mysqli_num_rows($sqlProgramas) > 0) 
    {
        $programas = mysqli_fetch_all($sqlProgramas, MYSQLI_ASSOC);

        echo json_encode($programas);
    } 
    
    else 
    {
        echo json_encode(["success" => 0]);
    }

    exit();


?>