<?php

    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With ");

    //Conexion a la base de datos

    $servidor = "localhost";
    $usuario = "root";
    $contrasenia= "";
    $nombreBaseDatos = "sena";

    $conexionBD= new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

    //Consultar datos y recepcionar una clave pk para la consulta

    if(isset ($_GET["consultar"]))
    {
        $sqlDesercion = mysqli_query($conexionBD, "SELECT * FROM desercion WHERE id = " . $_GET["consultar"]);

        if (mysqli_num_rows($sqlDesercion) > 0)
        {
            $deserciones = mysqli_fetch_all($sqlDesercion , MYSQLI_ASSOC);

            echo json_encode($deserciones);
        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();
    }


    // Borrar un registro, y recepcionar una clave pk para el borrado

    if(isset ($_GET["borrar"]))
    {
        $sqlDesercion = mysqli_query($conexionBD, "DELETE  FROM desercion WHERE id = " . $_GET["borrar"]);

        if ($sqlDesercion)
        {
            echo json_encode(["success"=>1]);

        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();
    }

    // Insertar un registro nuevo, y recepcionar por metodo POST los datos del aprendiz

    if (isset($_GET["insertar"]) && $_SERVER["REQUEST_METHOD"] === "POST") {
        $data = json_decode(file_get_contents("php://input"));
    
        if (!empty($data->nombre) && !empty($data->apellidos) && !empty($data->centro) && !empty($data->programa)) 
        {
            $nombre = $data->nombre;
            $apellidos = $data->apellidos;
            $tipoDocumento = $data->tipoDocumento;
            $centro = $data->centro;
            $codigoCentro = $data->codigoCentro;
            $programa = $data->programa;
            $numeroFicha = $data->numeroFicha;
            $instructor = $data->instructor;
            $fechaInicioPrograma = $data->fechaInicioPrograma;
            $jornada = $data->jornada;
            $fechaRetiroPrograma = $data->fechaRetiroPrograma;
            $causaRetiro = $data->causaRetiro;
            $descripcionCausa = $data->descripcionCausa;
            $observacion = $data->observacion;
    
            $sqlDesercion = mysqli_query($conexionBD, "INSERT INTO desercion (`nombre`, `apellidos`, `tipoDocumento`, `centro`, `codigoCentro`, `programa`, `numeroFicha`, `instructor`, `fechaInicioPrograma`, `jornada`, `fechaRetiroPrograma`, `causaRetiro`, `descripcionCausa`, `observacion`)
                VALUES ('$nombre', '$apellidos' , '$tipoDocumento', '$centro', '$codigoCentro', '$programa',  '$numeroFicha', '$instructor' ,'$fechaInicioPrograma', '$jornada' , '$fechaRetiroPrograma', '$causaRetiro' , '$descripcionCausa', '$observacion')");
    
            if ($sqlDesercion) {
                echo json_encode(["success" => 1]);
            } else {
                echo json_encode(["success" => 0]);
            }
        } else {
            echo json_encode(["success" => 0]);
        }
    
        exit();
    }
    
    

     //Actualiza un registro y recepciona por metodo POST los datos del aprendiz

     if(isset ($_GET["actualizar"]))
     {
        $id= $_GET['actualizar'];

        $data= json_decode(file_get_contents("php://input"));

        $nombre = $data->nombre;
        $apellidos = $data->apellidos;
        $tipoDocumento = $data->tipoDocumento;
        $centro = $data->centro;
        $codigoCentro = $data->codigoCentro;
        $programa = $data->programa;
        $numeroFicha = $data->numeroFicha;
        $instructor = $data->instructor;
        $fechaInicioPrograma = $data->fechaInicioPrograma;
        $jornada = $data->jornada;
        $fechaRetiroPrograma = $data->fechaRetiroPrograma;
        $causaRetiro = $data->causaRetiro;
        $descripcionCausa = $data->descripcionCausa;
        $observacion = $data->observacion;
        
        $sqlDesercion = mysqli_query($conexionBD, "UPDATE desercion  SET nombre = '$nombre', apellidos = '$apellidos', tipoDocumento = '$tipoDocumento', centro = '$centro', codigoCentro = '$codigoCentro', programa = '$programa', numeroFicha = '$numeroFicha', instructor = '$instructor', fechaInicioPrograma = '$fechaInicioPrograma', jornada = '$jornada', fechaRetiroPrograma = '$fechaRetiroPrograma', causaRetiro = '$causaRetiro',  descripcionCausa = '$descripcionCausa', observacion = '$observacion' WHERE id = $id");
    
        if ($sqlDesercion)
        {
            echo json_encode(["success"=>1]);

        }

        else{
            echo json_encode(["success"=>0]);
        }

        exit();

     }

     //Consultar todos los registros


    $sqlDesercion = mysqli_query($conexionBD, "SELECT * FROM desercion");

    if (mysqli_num_rows($sqlDesercion) > 0) 
    {
        $deserciones = mysqli_fetch_all($sqlDesercion, MYSQLI_ASSOC);

        echo json_encode($deserciones);
    } 
    
    else 
    {
        echo json_encode(["success" => 0]);
    }

    exit();


?>