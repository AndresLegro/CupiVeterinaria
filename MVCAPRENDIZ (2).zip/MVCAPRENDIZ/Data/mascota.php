<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With ");

    //Conexion a la base de datos

    $servidor = "localhost";
    $usuario = "root";
    $contrasenia= "";
    $nombreBaseDatos = "cupiveterinaria";

    $conexionBD= new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

    if (isset($_GET['consultar'])) {
        $idMascota = $_GET['consultar'];

        $sqlMascota = mysqli_query($conexionBD, "SELECT * FROM mascota WHERE id = $idMascota");

        if ($sqlMascota && mysqli_num_rows($sqlMascota) > 0) 
        {
            $mascota = mysqli_fetch_all($sqlMascota, MYSQLI_ASSOC);
            echo json_encode($mascota);
        } 
        else 
        {
            echo json_encode(["success" => 0]);
        }

        exit();
    }


    if(isset($_GET['borrar']))
    {
        $sqlMascota = mysqli_query($conexionBD, "DELETE FROM mascota WHERE id = " . $_GET["borrar"]);
        if($sqlMascota)
        {
            echo json_encode(["success" => 1]);
        }
        else
        {
            echo json_encode(["success" => 0]);
        }
        exit();
    }


    if(isset($_GET['insertar']))
    {
        $data = json_decode(file_get_contents("php://input"));

        $nombre = $data->nombre;
        $especie = $data->especie;
        $raza = $data->raza;
        $edad = $data->edad;
        $genero = $data->genero;
        $peso = $data->peso;


        if (!empty($nombre) && !empty($especie) && !empty($raza) && !empty($edad) && !empty($genero)) {
            
            $sqlMascota = mysqli_query($conexionBD, "INSERT INTO mascota (nombre, especie, raza, edad, genero, peso ) 
                                            VALUES ('$nombre', '$especie', '$raza', '$edad', '$genero', '$peso')");
            if($sqlMascota)
            {
                echo json_encode(["success" => 1]);
            }
            else
            {
                echo json_encode(["success" => 0]);
            }
        }
        exit();
    }

    if (isset($_GET['actualizar'])) 
    {
        $data = json_decode(file_get_contents("php://input"));

        $nombre = $data->nombre;
        $especie = $data->especie;
        $raza = $data->raza;
        $edad = $data->edad;
        $genero = $data->genero;
        $peso = $data->peso;

        if (!empty($nombre) && !empty($especie) && !empty($raza) && !empty($edad) && !empty($genero)) {
            $sqlMascota = mysqli_query($conexionBD, "UPDATE mascota SET nombre = '$nombre', especie = '$especie', raza = '$raza', edad = '$edad', genero = '$genero', peso = '$peso' WHERE id = " . $_GET['actualizar']);

            if($sqlMascota)
            {
                echo json_encode(["success" => 1]);
            }
            else
            {
                echo json_encode(["success" => 0]);
            }
        }

        exit();
    }


    $sqlMascota = mysqli_query($conexionBD, "SELECT * FROM mascota");

    if (mysqli_num_rows($sqlMascota) > 0) 
    {
        $mascota = mysqli_fetch_all($sqlMascota, MYSQLI_ASSOC);
        echo json_encode($mascota);
    }

    else 
    {
        echo json_encode(["success" => 0]);
    }

    exit();

?>