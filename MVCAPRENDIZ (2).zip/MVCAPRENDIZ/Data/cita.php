<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: access");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With ");

    //Conexion a la base de datos

    $servidor = "localhost";
    $usuario = "root";
    $contrasenia= "";
    $nombreBaseDatos = "cupiveterinaria";

    $conexionBD= new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

    if (isset($_GET['consultar'])) {
        $idCita = $_GET['consultar'];

        $sqlCita = mysqli_query($conexionBD, "SELECT * FROM cita WHERE id = $idCita");

        if ($sqlCita && mysqli_num_rows($sqlCita) > 0) 
        {
            $cita = mysqli_fetch_all($sqlCita, MYSQLI_ASSOC);
            echo json_encode($cita);
        } 
        else 
        {
            echo json_encode(["success" => 0]);
        }

        exit();
    }


    if(isset($_GET['borrar']))
    {
        $sqlCita = mysqli_query($conexionBD, "DELETE FROM cita WHERE id = " . $_GET["borrar"]);
        if($sqlCita)
        {
            echo json_encode(["success" => 1]);
        }
        else
        {
            echo json_encode(["success" => 0]);
        }
        exit();
    }


    if(isset($_GET['insertar']))
    {
        $data = json_decode(file_get_contents("php://input"));

        $fecha = $data->fecha;
        $hora = $data->hora;
        $tipo = $data->tipo;
        $doctor = $data->doctor;
        $motivo = $data->motivo;
        $idMascota = $data->idMascota;
        $idCliente = $data->idCliente;
        $sintomas = $data->sintomas;


        if (!empty($fecha) && !empty($hora) && !empty($tipo) && !empty($doctor) && !empty($motivo) && !empty($idMascota) && !empty($idCliente) && !empty($sintomas)) {
            
            $sqlCita = mysqli_query($conexionBD, "INSERT INTO cita (fecha, hora, tipo, doctor, motivo, idMascota, idCliente, sintomas ) 
                                            VALUES ('$fecha', '$hora', '$tipo', '$doctor', '$motivo', '$idMascota', '$idCliente', '$sintomas')");
            if($sqlCita)
            {
                echo json_encode(["success" => 1]);
            }
            else
            {
                echo json_encode(["success" => 0]);
            }
        }
        exit();
    }

    if (isset($_GET['actualizar'])) 
    {
        $data = json_decode(file_get_contents("php://input"));

        $estado = $data->estado;

        if (!empty($estado)) {
            $sqlCita = mysqli_query($conexionBD, "UPDATE cita SET estado = '$estado' WHERE id = " . $_GET['actualizar']);

            if($sqlCita)
            {
                echo json_encode(["success" => 1]);
            }
            else
            {
                echo json_encode(["success" => 0]);
            }
        }

        exit();
    }


    $sqlCita = mysqli_query($conexionBD, "SELECT * FROM cita");

    if (mysqli_num_rows($sqlCita) > 0) 
    {
        $cita = mysqli_fetch_all($sqlCita, MYSQLI_ASSOC);
        echo json_encode($cita);
    }

    else 
    {
        echo json_encode(["success" => 0]);
    }

    exit();

?>